-MSLdm 01 Dsrb555,frdba-iu-n x66)-
-Hs:lclot  aaae akpet- ---------------------------- evrvrin555-uut01.41
*411ST@L_HRCE_E_LET@CAATRSTCIN /
*411ST@L_HRCE_E_EUT=@HRCE_E_EUT /
*411ST@L_OLTO_ONCIN@CLAINCNETO /
*411STNMSuf /
*413ST@L_IEZN=@IEZN /
*413STTM_OE'0:0 /
*404ST@L_NQECEK=@NQECEK,UIU_HCS0*;/!01 E ODFRINKYCEK=@OEG_E_HCS OEG_E_HCS0*;/!00 E ODSLMD=@Q_OE Q_OE'OAT_AU_NZR'*;/!01 E ODSLNTS@SLNTS Q_OE= /
-
-Tbesrcuefrtbe`lse
-
RPTBEI XSS`lse;/!00 E svdc_let  =@caatrstcin /
*411STcaatrstcin  t8*;CET AL cas`( `yelse etNTNL, `alelse n()NTNL, `ieulse n()NTNL
 NIEInD EAL HRE=ai1
*411STcaatrstcin  svdc_let*;
-- upn aafrtbe`lse
-
OKTBE cas`WIE
*400ATRTBE`lse IAL ES*;ISR NO`lse AUS(BS2,02,'T '4,)
*400ATRTBE`lse NBEKY /
NOKTBE;
-- al tutr o al ue`-
DO AL FEIT ue`
*411ST@ae_scin    @hrce_e_let*;/!00 E hrce_e_let=uf /
RAETBE`sr 
 nm etNTNL, `rnm etNTNL, `g`it3 O UL)EGN=noBDFUTCASTltn;/!00 E hrce_e_let=@ae_scin /
-
-Dmigdt o al ue`-
LC ALS`sr RT;/!00 LE AL ue`DSBEKY /
NETIT ue`VLE 'ue''ue'2)(jgi''b,)(abl,jls,4,'oex,j'5)(abl,jls,4,'oex,j'5)
*400ATRTBE`sr NBEKY /
NOKTBE;/!00 E IEZN=ODTM_OE*;
*411STSLMD=ODSLMD /
*404STFRINKYCEK=ODFRINKYCEK /
*404STUIU_HCS@L_NQECEK /
*411STCAATRSTCIN=ODCAATRSTCIN /
*411STCAATRSTRSLS@L_HRCE_E_EUT /
*411STCLAINCNETO=ODCLAINCNETO /
*411STSLNTS@L_Q_OE /
- upcmltdo 070-21:40
*- yQ up1.3 iti ..5 o einlnxgu(8_4
-- ot oahs  Dtbs:bcuTs
----------------------------
-Sre eso	..50bnu.40.
/!00 E ODCAATRSTCIN=@HRCE_E_LET*;/!00 E ODCAATRSTRSLS@CAATRSTRSLS*;/!00 E ODCLAINCNETO=@OLTO_ONCIN*;/!00 E AE t8*;/!00 E ODTM_OE@TM_OE*;/!00 E IEZN=+00'*;/!01 E ODUIU_HCS@UIU_HCS NQECEK= /
*404ST@L_OEG_E_HCS@FRINKYCEK,FRINKYCEK= /
*411ST@L_Q_OE@SLMD,SLMD=N_UOVLEO_EO /
*411ST@L_Q_OE=@Q_OE,SLNTS0*;
-- al tutr o al cas`-
DO AL FEIT cas`
*411ST@ae_scin    @hrce_e_let*;/!00 E hrce_e_let=uf /
RAETBE`lse 
 tpCas`tx O UL
 tilCas`it2 O UL
 nvaCas`it1 O UL)EGN=noBDFUTCASTltn;/!00 E hrce_e_let=@ae_scin /
-
-Dmigdt o al cas`-
LC ALS`lse RT;/!00 LE AL cas`DSBEKY /
NETIT cas`VLE 'T '2,)(BS1,01;/!00 LE AL cas`EAL ES*;ULC ALS
-
-Tbesrcuefrtbe`sr
-
RPTBEI XSS`sr;/!00 E svdc_let  =@caatrstcin /
*411STcaatrstcin  t8*;CET AL ue`( `o`tx O UL
 peo`tx O UL
 ae n()NTNL
 NIEInD EAL HRE=ai1
*411STcaatrstcin  svdc_let*;
-- upn aafrtbe`sr
-
OKTBE ue`WIE
*400ATRTBE`sr IAL ES*;ISR NO`sr AUS(abl,jls,4,'oex,j'0,'ue''ue'2)(jgi''b,0,'ue''ue'2)(jgi''b,0;/!00 LE AL ue`EAL ES*;ULC ALS
*413STTM_OE@L_IEZN /
/!00 E Q_OE@L_Q_OE*;/!01 E OEG_E_HCS@L_OEG_E_HCS*;/!01 E NQECEK=ODUIU_HCS*;/!00 E HRCE_E_LET@L_HRCE_E_LET*;/!00 E HRCE_E_EUT=ODCAATRSTRSLS*;/!00 E OLTO_ONCIN@L_OLTO_ONCIN*;/!01 E Q_OE=ODSLNTS*;
-Dm opee n21-50 04:9.